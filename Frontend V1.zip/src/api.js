const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

async function request(path, options = {}) {
  const token = localStorage.getItem('learnly_token');
  const response = await fetch(`${API_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers },
    ...options,
  });
  if (!response.ok) throw new Error((await response.json().catch(() => ({}))).message || 'Something went wrong.');
  return response.status === 204 ? null : response.json();
}

export const api = {
  login: (credentials) => request('/auth/login', { method: 'POST', body: JSON.stringify(credentials) }),
  register: (details) => request('/auth/register', { method: 'POST', body: JSON.stringify(details) }),
  courses: () => request('/courses'),
  enroll: (courseId) => request(`/courses/${courseId}/enroll`, { method: 'POST' }),
  submitAssignment: (assignmentId, file) => { const form = new FormData(); form.append('file', file); return fetch(`${API_URL}/assignments/${assignmentId}/submissions`, { method: 'POST', headers: { Authorization: `Bearer ${localStorage.getItem('learnly_token')}` }, body: form }); },
};
