export const courses = [
  {
    id: 'react-zero-to-hero', title: 'React: Zero to Hero', category: 'Development', level: 'Beginner', instructor: 'Alex Morgan', rating: 4.9, students: 1248, duration: '12h 30m', lessons: 42, color: 'violet', description: 'Build modern, responsive interfaces while mastering React fundamentals.', progress: 64,
    modules: [
      { title: 'Getting started with React', lessons: [{ title: 'Welcome to the course', time: '04:20', done: true }, { title: 'How React works', time: '12:15', done: true }, { title: 'Your first component', time: '18:40', done: true }] },
      { title: 'Components and props', lessons: [{ title: 'Creating reusable components', time: '16:30', done: true }, { title: 'Working with props', time: '14:05', done: true }, { title: 'Component composition', time: '17:22', done: false }] },
      { title: 'State and events', lessons: [{ title: 'Understanding useState', time: '20:18', done: false }, { title: 'Handling user events', time: '15:42', done: false }] },
    ],
  },
  { id: 'ui-design', title: 'UI Design Foundations', category: 'Design', level: 'Beginner', instructor: 'Maya Chen', rating: 4.8, students: 983, duration: '8h 20m', lessons: 31, color: 'orange', description: 'Learn the visual and practical foundations of intuitive product design.', progress: 28 },
  { id: 'sql-masterclass', title: 'SQL for Data Analysis', category: 'Data Science', level: 'Intermediate', instructor: 'Noah Williams', rating: 4.7, students: 762, duration: '10h 15m', lessons: 38, color: 'blue', description: 'Write confident queries and turn raw data into useful insight.', progress: 0 },
  { id: 'digital-marketing', title: 'Digital Marketing Essentials', category: 'Marketing', level: 'Beginner', instructor: 'Sara Patel', rating: 4.9, students: 1560, duration: '7h 45m', lessons: 26, color: 'pink', description: 'Create digital campaigns that reach the right audience.', progress: 0 },
  { id: 'node-api', title: 'Node.js API Development', category: 'Development', level: 'Intermediate', instructor: 'Ethan Lee', rating: 4.8, students: 640, duration: '14h 10m', lessons: 48, color: 'green', description: 'Design and build reliable REST APIs with Node and Express.', progress: 0 },
  { id: 'productivity', title: 'Productivity Systems', category: 'Personal Development', level: 'Beginner', instructor: 'Jamie Brooks', rating: 4.6, students: 2140, duration: '5h 20m', lessons: 20, color: 'yellow', description: 'Build habits and systems that give your best work more room.', progress: 0 },
];

export const certificates = [
  { course: 'HTML & CSS Essentials', issued: '12 Oct 2026', code: 'LRN-8F29-A7C1', color: 'blue' },
];
